Se necesita mingw-64 instalado y seleccionado en las variables de entorneo de la computadora.
El programa necesita ser compilado en la versión C++17 en adelante.
Se necesita CLion o Vs Code.
Se necesita que la ruta del directorio a analizar no tenga ningún acento o carácter no válido en UTF-8.
El archivo style.css debe de estar en el mismo directorio en donde se encuentra el archivo .cpp.