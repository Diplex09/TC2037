Se necesita mingw-64 instalado y seleccionado en las variables de entorneo de la computadora.
Se necesita CLion o Vs Code.
Se necesita que la ruta del directorio a analizar no tenga ningún acento o carácter no válido en UTF-8.
El archivo style.css debe de estar en el mismo directorio en donde se encuentra el archivo .cpp.